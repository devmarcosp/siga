using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SigaApi.Data;
using SigaApi.Models;

namespace SigaApi.Controllers;

[ApiController]
[Route("api/docente")]
[Authorize(Roles = "DOCENTE")]
public class DocenteController(SigaDbContext db) : ControllerBase
{
    // El id del docente autenticado viaja dentro del token (NameIdentifier), nunca en la URL.
    private int IdDocenteActual => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private Task<List<int>> CursosIdsAsync() =>
        db.DocenteCursos.Where(dc => dc.IdDocente == IdDocenteActual).Select(dc => dc.IdCurso).ToListAsync();

    [HttpGet("cursos")]
    public async Task<IActionResult> Cursos()
    {
        var cursosIds = await CursosIdsAsync();
        var cursos = await db.Cursos.Where(c => cursosIds.Contains(c.IdCurso)).ToListAsync();
        return Ok(cursos.Select(c => new { c.IdCurso, c.NombreCurso, c.Nivel, c.Paralelo, c.Asignatura, c.AnioEscolar }));
    }

    [HttpGet("estudiantes")]
    public async Task<IActionResult> Estudiantes([FromQuery] int? idCurso)
    {
        var cursosIds = await CursosIdsAsync();
        var query = db.Estudiantes.Where(e => e.Activo && cursosIds.Contains(e.IdCurso));
        if (idCurso.HasValue) query = query.Where(e => e.IdCurso == idCurso);

        var resultado = await query.Select(e => new
        {
            e.IdEstudiante,
            e.Nombre,
            e.Rut,
            nombreCurso = e.Curso!.NombreCurso
        }).ToListAsync();
        return Ok(resultado);
    }

    [HttpGet("asistencia")]
    public async Task<IActionResult> Asistencia([FromQuery] int idCurso, [FromQuery] string fecha)
    {
        var cursosIds = await CursosIdsAsync();
        if (!cursosIds.Contains(idCurso)) return Forbid();

        var fechaFiltro = DateOnly.Parse(fecha);
        var estudiantes = await db.Estudiantes.Where(e => e.IdCurso == idCurso && e.Activo).ToListAsync();
        var resultado = new List<object>();
        foreach (var e in estudiantes)
        {
            var registro = await db.Asistencias.FirstOrDefaultAsync(a => a.IdEstudiante == e.IdEstudiante && a.Fecha == fechaFiltro);
            resultado.Add(new { e.IdEstudiante, e.Nombre, estado = registro?.Estado ?? "", observacion = registro?.Observacion ?? "" });
        }
        return Ok(resultado);
    }

    public record ItemAsistenciaDto(int IdEstudiante, string Fecha, string Estado, string? Observacion);

    [HttpPost("asistencia")]
    public async Task<IActionResult> GuardarAsistencia(List<ItemAsistenciaDto> items)
    {
        foreach (var i in items)
        {
            var fecha = DateOnly.Parse(i.Fecha);
            var existente = await db.Asistencias.FirstOrDefaultAsync(a => a.IdEstudiante == i.IdEstudiante && a.Fecha == fecha);
            if (existente != null)
            {
                existente.Estado = i.Estado;
                existente.Observacion = i.Observacion;
            }
            else
            {
                db.Asistencias.Add(new Asistencia { IdEstudiante = i.IdEstudiante, Fecha = fecha, Estado = i.Estado, Observacion = i.Observacion });
            }
        }
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpGet("calificaciones")]
    public async Task<IActionResult> Calificaciones([FromQuery] int? idCurso)
    {
        var cursosIds = await CursosIdsAsync();
        var query = db.Calificaciones.Where(c => cursosIds.Contains(c.IdCurso));
        if (idCurso.HasValue) query = query.Where(c => c.IdCurso == idCurso);

        var resultado = await query.Select(c => new
        {
            c.IdCalificacion,
            c.IdEstudiante,
            nombreEstudiante = db.Estudiantes.Where(e => e.IdEstudiante == c.IdEstudiante).Select(e => e.Nombre).FirstOrDefault(),
            c.IdCurso,
            c.TipoEvaluacion,
            c.Descripcion,
            c.Nota,
            c.Ponderacion,
            c.FechaRegistro,
            c.FechaNota
        }).ToListAsync();
        return Ok(resultado);
    }

    [HttpPost("calificaciones")]
    public async Task<IActionResult> CrearCalificacion(Calificacion data)
    {
        var cursosIds = await CursosIdsAsync();
        if (!cursosIds.Contains(data.IdCurso)) return BadRequest(new { mensaje = "No tienes acceso a este curso" });

        data.FechaRegistro = data.FechaRegistro == default ? DateOnly.FromDateTime(DateTime.Now) : data.FechaRegistro;
        db.Calificaciones.Add(data);
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpPut("calificaciones/{id}")]
    public async Task<IActionResult> EditarCalificacion(int id, Calificacion data)
    {
        var cal = await db.Calificaciones.FindAsync(id);
        if (cal == null) return NotFound(new { mensaje = "Calificacion no encontrada" });
        cal.Nota = data.Nota;
        cal.Ponderacion = data.Ponderacion;
        cal.TipoEvaluacion = data.TipoEvaluacion;
        cal.Descripcion = data.Descripcion;
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpDelete("calificaciones/{id}")]
    public async Task<IActionResult> EliminarCalificacion(int id)
    {
        var cal = await db.Calificaciones.FindAsync(id);
        if (cal == null) return NotFound();
        db.Calificaciones.Remove(cal);
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpGet("anotaciones")]
    public async Task<IActionResult> Anotaciones()
    {
        var anotaciones = await db.Anotaciones.Where(a => a.IdDocente == IdDocenteActual).ToListAsync();
        return Ok(anotaciones);
    }

    public record NuevaAnotacionDto(int IdEstudiante, int? IdCurso, string Tipo, string Observacion);

    [HttpPost("anotaciones")]
    public async Task<IActionResult> CrearAnotacion(NuevaAnotacionDto dto)
    {
        db.Anotaciones.Add(new Anotacion
        {
            IdEstudiante = dto.IdEstudiante,
            IdDocente = IdDocenteActual,
            IdCurso = dto.IdCurso,
            Tipo = dto.Tipo,
            Observacion = dto.Observacion,
            FechaRegistro = DateTime.Now
        });
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpGet("materiales")]
    public async Task<IActionResult> Materiales([FromQuery] int? idCurso)
    {
        var cursosIds = await CursosIdsAsync();
        var query = db.Materiales.Where(m => cursosIds.Contains(m.IdCurso));
        if (idCurso.HasValue) query = query.Where(m => m.IdCurso == idCurso);
        return Ok(await query.ToListAsync());
    }

    [HttpPost("materiales")]
    public async Task<IActionResult> SubirMaterial(IFormFile file, [FromForm] int idCurso)
    {
        var cursosIds = await CursosIdsAsync();
        if (!cursosIds.Contains(idCurso)) return BadRequest(new { mensaje = "No tienes acceso a este curso" });

        // Se guarda el archivo en disco (wwwroot/materiales) y solo la ruta en la BD.
        var carpeta = Path.Combine("wwwroot", "materiales");
        Directory.CreateDirectory(carpeta);
        var nombreArchivo = $"{Guid.NewGuid()}_{file.FileName}";
        var rutaFisica = Path.Combine(carpeta, nombreArchivo);
        await using (var stream = new FileStream(rutaFisica, FileMode.Create))
            await file.CopyToAsync(stream);

        db.Materiales.Add(new Material
        {
            IdCurso = idCurso,
            IdDocente = IdDocenteActual,
            Titulo = file.FileName,
            TipoArchivo = Path.GetExtension(file.FileName).TrimStart('.').ToUpper(),
            RutaArchivo = $"/materiales/{nombreArchivo}",
            FechaSubida = DateTime.Now
        });
        await db.SaveChangesAsync();
        return Ok(true);
    }

    [HttpDelete("materiales/{id}")]
    public async Task<IActionResult> EliminarMaterial(int id)
    {
        var mat = await db.Materiales.FindAsync(id);
        if (mat == null) return NotFound();
        db.Materiales.Remove(mat);
        await db.SaveChangesAsync();
        return Ok(true);
    }
}
