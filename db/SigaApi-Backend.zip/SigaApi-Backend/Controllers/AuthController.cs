using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SigaApi.Data;

namespace SigaApi.Controllers;

public record LoginRequest(string Identificador, string Contrasena);

[ApiController]
[Route("api/auth")]
public class AuthController(SigaDbContext db, IConfiguration config) : ControllerBase
{
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest req)
    {
        // Se busca el correo en las 3 tablas de rol (no hay tabla Usuario central)
        var admin = await db.Administradores.FirstOrDefaultAsync(a => a.Correo == req.Identificador && a.Activo);
        if (admin != null && BCrypt.Net.BCrypt.Verify(req.Contrasena, admin.ContrasenaHash))
            return Ok(GenerarRespuesta(admin.IdAdministrador, admin.Nombre, "ADMIN"));

        var docente = await db.Docentes.FirstOrDefaultAsync(d => d.Correo == req.Identificador && d.Activo);
        if (docente != null && BCrypt.Net.BCrypt.Verify(req.Contrasena, docente.ContrasenaHash))
        {
            var cursosAsignados = await db.DocenteCursos
                .Where(dc => dc.IdDocente == docente.IdDocente)
                .Select(dc => dc.IdCurso)
                .ToListAsync();
            return Ok(GenerarRespuesta(docente.IdDocente, docente.Nombre, "DOCENTE", cursosAsignados: cursosAsignados));
        }

        var apoderado = await db.Apoderados.FirstOrDefaultAsync(a => a.Correo == req.Identificador && a.Activo);
        if (apoderado != null && BCrypt.Net.BCrypt.Verify(req.Contrasena, apoderado.ContrasenaHash))
        {
            var pupilo = await db.Estudiantes.FirstOrDefaultAsync(e => e.IdApoderado == apoderado.IdApoderado);
            return Ok(GenerarRespuesta(apoderado.IdApoderado, apoderado.Nombre, "APODERADO", pupiloId: pupilo?.IdEstudiante));
        }

        return Unauthorized(new { mensaje = "Credenciales invalidas" });
    }

    [HttpPost("logout")]
    public IActionResult Logout() => Ok(true);

    private object GenerarRespuesta(int id, string nombre, string rol, List<int>? cursosAsignados = null, int? pupiloId = null)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, id.ToString()),
            new(ClaimTypes.Role, rol)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            claims: claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: creds);

        return new
        {
            identificador = id,
            nombre,
            rol,
            token = new JwtSecurityTokenHandler().WriteToken(token),
            cursosAsignados,
            pupiloId
        };
    }
}
